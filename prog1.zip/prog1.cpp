#include <mpi.h>

#include <math.h>       /* cos */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

double fRand(double fMin, double fMax)
{
    double f = (double)rand() / RAND_MAX;
    return fMin + f * (fMax - fMin);
}

int dboard(int N, MPI_Comm comm){

    double radius = 2.0;

    int p, rank;
    MPI_Comm_size(comm, &p);
    MPI_Comm_rank(comm, &rank);

    // Compute number of darts to be thrown locally
    // std::default_random_engine generator(rank); // rd() provides a random seed
    // std::uniform_real_distribution<double> distributionA(0,radius * radius); //Replace r^2 with the proper number value
    // std::uniform_real_distribution<double> distributionTheta(0,2 * M_PI); //Replace r^2 with the proper number value

    // printf("%d\n", (time(NULL) % 100)*p + rank*100);
    srand((time(NULL) % 1000)*p + rank*1000);

    int numberOfDartsToThrow = N/p;
    if (N % p > rank) {
        numberOfDartsToThrow++;
    }

    // printf("number of darts to throw: %d\n", numberOfDartsToThrow);

    int m = 0;
    for(int i = 0; i < numberOfDartsToThrow; i++){
        // double a = distributionA(generator);
        // double theta = distributionTheta(generator);

        double a = fRand(0, radius * radius);
        double theta = fRand(0, 2 * M_PI);

        double x = sqrt(a) * cos(theta);
        double y = sqrt(a) * sin(theta);

        if (x < 0) {
            x = x * -1;
        }
        if (y < 0) {
            y = y * -1;
        }

        if (x <= (radius/sqrt(2)) && y <= (radius/sqrt(2))){
            m++;
        }
    }
    return m;
}

int main(int argc, char* argv[]) {

    MPI_Init(&argc, &argv);

    int MASTER = 0;

    int N = atoi(argv[1]);
    int R = atoi(argv[2]);

    double pi = 0.0;

    // get communicator size and my rank
    MPI_Comm comm = MPI_COMM_WORLD;
    int p, rank;
    MPI_Comm_size(comm, &p);
    MPI_Comm_rank(comm, &rank);

    // printf("1 %d %d\n", p, rank);

    // printf("2 %d %d\n", N, R);

    MPI_Bcast(&N, 1, MPI_INT, 0, comm);
    int totalTime;
    for (int i = 0; i < R; i++) {
        int startTime = clock();
        int m = dboard(N, comm);
        int sum;

        int timeDiff = clock() - startTime;
        // int totalTime;

        int reductionTimeStart = clock();
        MPI_Reduce(&m, &sum, 1, MPI_INT, MPI_SUM, MASTER, comm);
        MPI_Reduce(&timeDiff, &totalTime, 1, MPI_INT, MPI_MAX, MASTER, comm);

        if (rank == MASTER) {
            double newPI = 2 * ((double)N / sum);

            double temp = pi;
            temp *= i;
            temp += newPI;

            pi = temp / (i+1);

            totalTime += clock() - reductionTimeStart + timeDiff;
        }
    }

    MPI_Finalize();
    if (rank == MASTER) {
        printf("N = %d, R = %d, P = %d, PI = %f\n", N, R, p, pi);
        double time_taken = ((double)totalTime)/CLOCKS_PER_SEC;
        printf("TIME = %f\n", time_taken);
    }
    return 0;
}
